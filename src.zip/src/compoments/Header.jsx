import React from 'react'

export default function Header(props) {
  return (
    <h1 className='white padtop'>{props.title}</h1>
  )
}
